let number = -1; 

if (number > 0) {
    console.log("The number is positive.");
} else{
    console.log("The number is negative.");

}


// CARL ANGELO ROBAS
// T2023-0082