let num1 = 15;
let num2 = 20;

if(num1 > num2){
    console.log("number1 is greater.");
}else{
    console.log("number2 is greater.");
}

// CARL ANGELO ROBAS
// T2023-0082