class Vehicle {
    constructor(name, model, weight, color){
        this.name = name;
        this.model = model;
        this.color = color;
        this.weight = weight;
    }

    displayDetails(){
        console.log(`Name: ${this.name}`);
        console.log(`Model: ${this.model}`);
        console.log(`Weight: ${this.weight}`);
        console.log(`Color: ${this.color}`);
        
    }
}

const vehicle1 = new Vehicle('Honda', 'mobilio', '300kg', 'White');

console.log('Vehicle-1 Details: ');
vehicle1.displayDetails();
console.log('\n');

const vehicle2 = new Vehicle('Toyota', 'fortuner', '200kg', 'Blue');
console.log('Vehicle-2 Details: ');
vehicle2.displayDetails();



// CARL ANGELO ROBAS
// T2023-0082