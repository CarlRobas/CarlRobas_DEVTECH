<!DOCTYPE html>
<html>
<head>
    <title>PostForm.php</title>
    <style>
        label {
            display: inline-block;
            width: 220px; /* Adjust the width as needed */
            margin-bottom: 5px;
        }
        input, select {
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <form action="postform_submitted.php" method="post">
        <h2>PostForm.php</h2>
        <label>My name is:</label>
        <input type="text" name="name" required><br>

        <label>My favourite movie is:</label>
        <input type="text" name="movie" required><br>

        <label>My degree is:</label>
        <select name="degree">
            <option value="Bachelor">Bachelor</option>
            <option value="Master">Master</option>
        </select><br>

        <label>Gender:</label> 
        <input type="radio" name="gender" value="Male" required> Male 
        <input type="radio" name="gender" value="Female" required> Female<br>

        <label>My favourite unit(s) *multiselect:</label>
        <select name="subjects[]" multiple size="3">
            <option value="Math">Math</option>
            <option value="Science">Science</option>
            <option value="History">History</option>
        </select><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
