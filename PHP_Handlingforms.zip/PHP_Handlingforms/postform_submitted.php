<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "quiz_data";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$name = $_POST['name'];
$movie = $_POST['movie'];
$degree = $_POST['degree'];
$gender = $_POST['gender'];
$subjects = implode(", ", $_POST['subjects']);

// Insert data into database
$sql = "INSERT INTO responses (name, movie, degree, gender, subjects)
        VALUES ('$name', '$movie', '$degree', '$gender', '$subjects')";

if ($conn->query($sql) === TRUE) {
    echo "<h2>postform_submitted.php</h2>";
    echo "Hello $name<br><br>";
    echo "You like movie \"$movie\"<br>";
    echo "You are enrolled in $degree Degree.<br>";
    echo "Your gender is $gender.<br>";
    echo "Your favorite subjects are $subjects.<br>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
