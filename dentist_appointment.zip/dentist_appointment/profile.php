<?php
session_start();
include('db_connection.php');  // Include the combined DB connection file

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id']; // Get the logged-in user's ID

// Fetch user appointments from the dental_system
$appointment_query = "SELECT * FROM appointments WHERE user_id = ?";
$appointment_stmt = $conn1->prepare($appointment_query);
$appointment_stmt->bind_param("i", $user_id);
$appointment_stmt->execute();
$appointments_result = $appointment_stmt->get_result();

// Handle new appointment booking
if (isset($_POST['book_appointment'])) {
    $date = $_POST['appointment_date'];
    $time = $_POST['appointment_time'];
    $appointment_query = "INSERT INTO appointments (user_id, appointment_date, appointment_time) VALUES (?, ?, ?)";
    $appointment_stmt = $conn1->prepare($appointment_query);
    $appointment_stmt->bind_param("iss", $user_id, $date, $time);

    if ($appointment_stmt->execute()) {
        $appointment_message = "Appointment booked successfully!";
    } else {
        $appointment_message = "There was an error booking your appointment.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <div class="container">
        <h1>Your Appointments</h1>

        <!-- Display success or error message for booking appointment -->
        <?php if (isset($appointment_message)): ?>
            <p><?php echo $appointment_message; ?></p>
        <?php endif; ?>

        <!-- Display current appointments -->
        <?php if ($appointments_result->num_rows > 0): ?>
            <table>
                <tr>
                    <th>Appointment Date</th>
                    <th>Appointment Time</th>
                </tr>
                <?php while ($appointment = $appointments_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $appointment['appointment_date']; ?></td>
                        <td><?php echo $appointment['appointment_time']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>You have no appointments scheduled.</p>
        <?php endif; ?>

        <!-- Book New Appointment -->
        <h2>Book a New Appointment</h2>
        <form action="profile.php" method="POST">
            <label for="appointment_date">Appointment Date</label>
            <input type="date" id="appointment_date" name="appointment_date" required>

            <label for="appointment_time">Appointment Time</label>
            <input type="time" id="appointment_time" name="appointment_time" required>

            <button type="submit" name="book_appointment">Book Appointment</button>
        </form>

    </div>

</body>
</html>
