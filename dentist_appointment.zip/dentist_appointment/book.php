<?php
date_default_timezone_set('Asia/Manila'); // Set the timezone to Asia/Manila
session_start();
include 'db_connection.php'; // Include the database connection

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Initialize message variable
$message = '';
$success = false; // Flag to indicate success

// Fetch dentists from the users table (role = 'dentist')
$query = "SELECT id, username FROM users WHERE role = 'dentist'";
$dentists = $conn->query($query);

// Handle form submission for booking an appointment
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['time_slot'];
    $reason = $_POST['reason'];
    $dentist_id = $_POST['dentist_id']; // Selected dentist ID

    // Check if all fields are filled
    if (empty($appointment_date) || empty($appointment_time) || empty($reason) || empty($dentist_id)) {
        $message = "All fields are required!";
    } else {
        // Convert the appointment time to 24-hour format if necessary
        $time = date("H:i", strtotime($appointment_time));  // Convert 12-hour time to 24-hour format

        // Insert appointment into database
        $query = "INSERT INTO appointments (user_id, dentist_id, appointment_date, time_slot, reason, status) 
                  VALUES (?, ?, ?, ?, ?, 'Booked')";
        $stmt = $conn->prepare($query);

        if ($stmt) {
            $stmt->bind_param("iisss", $user_id, $dentist_id, $appointment_date, $time, $reason);

            if ($stmt->execute()) {
                $message = "Appointment booked successfully!";
                $success = true;
            } else {
                $message = "Error: " . $stmt->error;  // Display error message if execution fails
            }
        } else {
            $message = "Failed to prepare the query.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Appointment</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #81D4FA, #4FC3F7);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .header {
            background-color: #007bff;
            color: white;
            padding: 20px 0;
            text-align: center;
            font-size: 28px;
            font-weight: bold;
        }

        .navbar {
            background-color: #4FC3F7;
            display: flex;
            justify-content: center;
            padding: 15px 0;
        }

        .navbar a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            margin: 0 20px;
            transition: background-color 0.3s ease;
            padding: 10px 20px;
            border-radius: 5px;
        }

        .navbar a:hover {
            background-color: #007bff;
        }

        .content {
            display: flex;
            justify-content: center;
            margin: 30px;
            flex-grow: 1;
        }

        .appointment-form {
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            width: 400px;
            display: flex;
            flex-direction: column;
        }

        .appointment-form h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }

        .appointment-form label {
            font-size: 16px;
            color: #333;
            margin-bottom: 5px;
        }

        .appointment-form input,
        .appointment-form textarea,
        .appointment-form select {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 10px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        .appointment-form input[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            padding: 12px;
            border-radius: 10px;
        }

        .appointment-form input[type="submit"]:hover {
            background-color: #00BCD4;
        }

        .message {
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            margin-top: 20px;
            padding: 20px;
            color: #000; /* Change text color to black */
            background-color: #FFFFFF;
            border-radius: 15px;
            width: 20%;
            margin: 30px auto;
            position: relative;
        }

        .back-to-dashboard {
            text-align: center;
            margin-top: 20px;
            position: absolute;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
        }

        .back-to-dashboard a {
            text-decoration: none;
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border-radius: 10px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .back-to-dashboard a:hover {
            background-color: #00BCD4;
        }

        .footer {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: auto;
        }
    </style>
</head>
<body>

<div class="header">
    <h1>Book Your Appointment</h1>
</div>

<div class="navbar">
    <a href="dashboard.php">Dashboard</a>
    <a href="view_appointments.php">View Appointments</a>
    <a href="logout.php">Logout</a>
</div>

<div class="content">
    <?php if ($success): ?>
        <div class="message"><?php echo $message; ?>
            <div class="back-to-dashboard">
                <a href="dashboard.php">Back to Dashboard</a>
            </div>
        </div>
    <?php else: ?>
        <form action="book.php" method="POST" class="appointment-form">
            <h2>Appointment Booking Form</h2>

            <!-- Display success or error message -->
            <?php if ($message): ?>
                <div class="message"><?php echo $message; ?></div>
            <?php endif; ?>

            <label for="appointment_date">Appointment Date</label>
            <input type="date" id="appointment_date" name="appointment_date" required>

            <label for="appointment_time">Appointment Time</label>
            <input type="time" id="time_slot" name="time_slot" required>

            <label for="reason">Reason for Visit</label>
            <textarea id="reason" name="reason" rows="4" required></textarea>

            <label for="dentist_id">Select Dentist</label>
            <select name="dentist_id" id="dentist_id" required>
                <option value="">-- Select Dentist --</option>
                <?php while ($dentist = $dentists->fetch_assoc()): ?>
                    <option value="<?php echo $dentist['id']; ?>"><?php echo $dentist['username']; ?></option>
                <?php endwhile; ?>
            </select>

            <input type="submit" value="Book Appointment">
        </form>
    <?php endif; ?>
</div>

<div class="footer">
    <p>&copy; 2024 BrightSmile Dental Care. All Rights Reserved.</p>
</div>

</body>
</html>
