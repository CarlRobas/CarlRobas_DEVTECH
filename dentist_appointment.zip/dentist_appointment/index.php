<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - Dentist Appointment System</title>
    <style>
        body {
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            color: #333;
        }

        header {
            background-color: #007bff;
            color: #fff;
            padding: 20px 10px;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 2.5rem;
        }

        header p {
            margin: 10px 0 0;
            font-size: 1.2rem;
            color: #e0e0e0;
        }

        .container {
            text-align: center;
            margin: 50px auto;
            max-width: 800px;
            padding: 30px;
            background-color: #fff;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
        }

        .container h2 {
            margin-bottom: 20px;
            font-size: 1.8rem;
            color: #333;
        }

        .container p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            line-height: 1.6;
            color: #555;
        }

        .buttons a {
            display: inline-block;
            margin: 0 15px;
            padding: 12px 20px;
            font-size: 1rem;
            color: #fff;
            background-color: #007bff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .buttons a:hover {
            background-color: #0056b3;
        }

        footer {
            text-align: center;
            margin-top: 50px;
            padding: 20px 0;
            background-color: #007bff;
            color: #fff;
            font-size: 0.9rem;
        }

        footer a {
            color: #e0e0e0;
            text-decoration: underline;
        }

        footer a:hover {
            color: #fff;
        }
    </style>
</head>
<body>
    <header>
        <h1>BrightSmile Dental Care</h1>
        <p>Convenient and easy appointment management</p>
    </header>
    <div class="container">
        <h2>Welcome!</h2>
        <p>
            Manage your dental appointments effortlessly. 
            Whether you want to book a new appointment, view your existing ones, or connect with our trusted dentists, we've got you covered. 
        </p>
        <div class="buttons">
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        </div>
    </div>
    <footer>
        <p>&copy; 2024 BrightSmile Dental Care. All Rights Reserved.</p>
        <p><a href="#">Terms of Service</a> | <a href="#">Privacy Policy</a></p>
    </footer>
</body>
</html>
