<?php
session_start();

// Database connection settings
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'dentist_appointment';

// Establish database connection
$conn = new mysqli($host, $username, $password, $database);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

$user_id = $_SESSION['user_id']; // Get the logged-in user ID

// Fetch appointments for the logged-in user
$sql = "SELECT 
a.id, 
DATE(a.appointment_time) AS appointment_date, 
TIME(a.appointment_time) AS time_slot, 
d.name AS dentist_name, 
a.status 
FROM appointments a
JOIN dentists d ON a.dentist_id = d.id
WHERE a.user_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id); // Bind the user_id as integer to the query
$stmt->execute();
$result = $stmt->get_result(); // Get the result of the query
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Appointments</title>
    <style>
        body {
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            color: #333;
        }

        header {
            background-color: #007bff;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 1.8rem;
        }

        .container {
            margin: 50px auto;
            max-width: 800px;
            background: #fff;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
        }

        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .success-message {
            text-align: center;
            color: green;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .btn-back {
            text-align: center;
            margin-top: 20px;
        }

        .btn-back a {
            text-decoration: none;
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
        }

        .btn-back a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <h1>My Appointments</h1>
    </header>
    <div class="container">
        <?php if (isset($_SESSION['success_message'])) { ?>
            <div class="success-message">
                <?php echo $_SESSION['success_message']; ?>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php } ?>

        <h2>Your Appointment History</h2>

        <?php if ($result->num_rows > 0) { ?>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Dentist</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['appointment_date']; ?></td>
                            <td>
                                <?php 
                                // Check if time_slot is set and not empty
                                if (!empty($row['time_slot'])) {
                                    $time = new DateTime($row['time_slot']);
                                    echo $time->format('H:i');  // Display as HH:MM format
                                } else {
                                    echo 'No time set';
                                }
                                ?>
                            </td>
                            <td><?php echo $row['dentist_name']; ?></td> <!-- Display dentist's name -->
                            <td><?php echo ucfirst($row['status']); ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } else { ?>
            <p style="text-align: center; color: #555;">No appointments found. Book one now!</p>
        <?php } ?>

        <div class="btn-back">
            <a href="dashboard.php">Back to Dashboard</a>
        </div>
    </div>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
