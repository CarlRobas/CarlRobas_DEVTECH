<?php
session_start();
include('db_connection.php');

// Ensure the user is logged in, else redirect to login page
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Fetch user details (example: retrieve user name)
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Dentist Appointment System</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #81D4FA, #4FC3F7);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .header {
            background-color: #007bff;
            color: white;
            padding: 20px 0;
            text-align: center;
            font-size: 24px;
        }

        .navbar {
            background-color: #4FC3F7;
            display: flex;
            justify-content: center;
            padding: 15px 0;
        }

        .navbar a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            margin: 0 20px;
            transition: background-color 0.3s ease;
            padding: 10px 20px;
            border-radius: 5px;
        }

        .navbar a:hover {
            background-color: #007bff;
        }

        .content {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin: 30px;
        }

        .card {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            width: 250px;
            margin: 15px;
            padding: 20px;
            text-align: center;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-10px);
        }

        .card h3 {
            color: #007bff;
            font-size: 22px;
            margin-bottom: 15px;
        }

        .card p {
            color: #555;
            font-size: 16px;
            margin-bottom: 20px;
        }

        .card button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .card button:hover {
            background-color: #00BCD4;
        }

        .footer {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: auto;
        }
    </style>
</head>
<body>

    <div class="header">
        <h1>Welcome, <?php echo htmlspecialchars($user['username']); ?>!</h1>
        <p>Your Dashboard</p>
    </div>

    <div class="navbar">
        <a href="view_appointments.php">View Appointments</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="content">
        <div class="card">
            <h3>Book Appointment</h3>
            <p>Schedule your next dental visit.</p>
            <button onclick="window.location.href='book.php'">Book Now</button>
        </div>
        <div class="card">
            <h3>Your Appointments</h3>
            <p>View your upcoming and past appointments.</p>
            <button onclick="window.location.href='view_appointments.php'">View Appointments</button>
        </div>
       
    </div>

    <div class="footer">
        <p>&copy; 2024 BrightSmile Dental Care. All Rights Reserved.</p>
    </div>

</body>
</html>
