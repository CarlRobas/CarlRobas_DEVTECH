<?php
date_default_timezone_set('Asia/Manila'); // Set the timezone to Asia/Manila
session_start();
include 'db_connection.php'; // Include the database connection

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

$user_id = $_SESSION['user_id']; // Get the logged-in user ID

// Fetch appointments for the logged-in user
$sql = "SELECT a.id, a.appointment_date, a.time_slot, u.username AS dentist_name, a.status 
        FROM appointments a
        JOIN users u ON a.dentist_id = u.id
        WHERE a.user_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id); // Bind the user_id as integer to the query
$stmt->execute();
$result = $stmt->get_result(); // Get the result of the query
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Appointments</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #007bff;
            color: white;
            padding: 20px 0;
            text-align: center;
            font-size: 28px;
        }

        .navbar {
            background-color: #4FC3F7;
            display: flex;
            justify-content: center;
            padding: 15px 0;
        }

        .navbar a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            margin: 0 20px;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .navbar a:hover {
            background-color: #007bff;
        }

        .appointments-container {
            margin: 30px auto;
            width: 90%;
            max-width: 1000px;
            background: #fff;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        th {
            background-color: #007bff;
            color: white;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .footer {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: auto;
        }

        .footer p {
            margin: 0;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Your Appointments</h1>
    </header>

    <div class="navbar">
        <a href="dashboard.php">Dashboard</a>
        <a href="book.php">Book Appointment</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="appointments-container">
        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Dentist</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo date('F j, Y', strtotime($row['appointment_date'])); ?></td>
                            <td><?php echo date('g:i A', strtotime($row['time_slot'])); ?></td> <!-- Format time in AM/PM -->
                            <td><?php echo $row['dentist_name']; ?></td>
                            <td><?php echo ucfirst($row['status']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="text-align: center; color: #555;">No appointments found. Book one now!</p>
        <?php endif; ?>
    </div>

    <div class="footer">
        <p>&copy; 2024 BrightSmile Dental Care. All Rights Reserved.</p>
    </div>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
