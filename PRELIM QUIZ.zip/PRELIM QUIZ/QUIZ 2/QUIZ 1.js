let number = 4;

if (number & 2 === 0){
    console.log("The number is even.");

}else{
    console.log("The number is odd.");
}

// CARL ANGELO ROBAS
// T2023-0082