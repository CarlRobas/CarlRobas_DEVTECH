class Book{
    constructor(title, author, publication,){
        this.title=title;
        this.author=author;
        this.publication=publication;
    }
    displayDetails(){
        console.log(`Title: ${this.title}`);
        console.log(`Author: ${this.author}`);
        console.log(`Publication Year: ${this.publication}`);
    }
}

class Ebook extends B   ook{
    constructor(title, author, publication, price){
        super(title, author, publication);
        this.price=price;
    }
    displayDetails(){
        super.displayDetails();
        console.log(`Price: ${this.price}`);

    }
} 
const book = new Book('The Attachment Style', 'Ria Martez', 2024, '$300.9');

console.log('Book Details:');
book.displayDetails();

const book = new Book('Harry Potter', 'JK Rowling', 1900, '$19.08');

console.log('\nBook Details:');
book.displayDetails();