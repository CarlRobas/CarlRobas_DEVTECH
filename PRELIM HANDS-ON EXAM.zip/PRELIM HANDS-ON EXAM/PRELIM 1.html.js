class Book{
    constructor(title, author, publicationYear){
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;

    }
    
    displayDetails(){
        console.log(`Title: ${this.title}`);
        console.log(`Author: ${this.author}`);
        console.log(`Publication Year: ${this.publicationYear}`);
    }
}

class Ebook extends Book {
    constructor(title, author, publicationYear, price){
        super(title, author, publicationYear);
        this.price = price;
}

displayDetails(){
    super.displayDetails();
    console.log(`Price: $${this.price}`);
    }
}

const ebook1 = new Ebook("The Attachment Style" ,"Ria Martez",2024, 300.9);
const ebook2 = new Ebook("Harry Potter","JK Rowling", 1900, 19.08);
const ebook3 = new Ebook("Don Quixole","Author 2", 1988, 25.33);

ebook1.displayDetails();
ebook2.displayDetails();
ebook3.displayDetails();
